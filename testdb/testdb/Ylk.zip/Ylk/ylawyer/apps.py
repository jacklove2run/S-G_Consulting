from django.apps import AppConfig


class YlawyerConfig(AppConfig):
    name = 'ylawyer'
